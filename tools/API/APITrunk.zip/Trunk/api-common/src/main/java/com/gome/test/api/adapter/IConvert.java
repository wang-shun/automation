package com.gome.test.api.adapter;

import java.util.Map;

/**
 * Created by zhangjiadi on 15/9/17.
 */
public interface IConvert {

    public Map<String,Object> convertMap(Map<String,String> map);


}
