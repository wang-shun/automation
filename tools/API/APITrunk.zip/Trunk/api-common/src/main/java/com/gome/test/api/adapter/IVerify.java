package com.gome.test.api.adapter;

public interface IVerify {
    public void verify(Object obj);
}